import pyodide

__all__ = ["display", "display_image", "HTML"]


display = pyodide.Basthon.basthon_internal.display

display_image = pyodide.Basthon.basthon_internal.display_image


def HTML(html):
    """ Sending html string to IPython notebook. """
    def _repr_html_():
        return html
    dummy = type('HTML', (), {})()
    dummy._repr_html_ = _repr_html_
    return display(dummy)
